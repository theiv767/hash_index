import streamlit as st
import pandas as pd
from scripts.structures import Table, Bucket

# Função para processar o arquivo e retornar o DataFrame
def process_file(file):
    df = pd.read_csv(file)
    return df

# Interface do Streamlit
st.title("Uploader de Arquivo com Configuração de Variáveis")

# Criação de abas
tab1, tab2 = st.tabs(["Upload e Configuração", "Visualização de Dados"])

# Aba 1: Upload e Configuração
with tab1:
    # Upload do arquivo
    uploaded_file = st.file_uploader("Escolha um arquivo CSV", type="csv")

    if uploaded_file is not None:
        # Receber os valores das variáveis
        numero_buckets = st.number_input("Número de Buckets", min_value=1, value=1)
        tamanho_buckets = st.number_input("Tamanho dos Buckets", min_value=1, value=1)
        tamanho_paginas = st.number_input("Tamanho das Páginas", min_value=1, value=1)

        # Processar o arquivo
        df = process_file(uploaded_file)

        # Mostrar algumas informações básicas do DataFrame
        st.write("Aqui estão as primeiras linhas do arquivo carregado:")
        st.write(df.head())

        # Mostrar os valores das variáveis
        st.write(f"Número de Buckets: {numero_buckets}")
        st.write(f"Tamanho dos Buckets: {tamanho_buckets}")
        st.write(f"Tamanho das Páginas: {tamanho_paginas}")

        # Adicionar dadoos Bucketsdo
        st.session_state.df = df
        st.session_state.numero_buckets = numero_buckets
        st.session_state.tamanho_buckets = tamanho_buckets
        st.session_state.tamanho_paginas = tamanho_paginas

        # Botão "Aplicar"
        if st.button("Aplicar"):
            # Definir campos e chave primária
            fields = df.columns.tolist()
            primary_key = fields[0]  # Supondo que a primeira coluna é a chave primária
            bucket_size = tamanho_buckets
            page_size = tamanho_paginas

            # Criar uma instância de Table
            table = Table(fields, primary_key, page_size)

            # Criar uma instância de Bucket
            bucket = Bucket(numero_buckets, bucket_size, table)

            # Adicionar registros à tabela e buckets
            for _, row in df.iterrows():
                row_dict = row.to_dict()
                bucket.add_value(row_dict)

            st.session_state.table = table
            st.session_state.bucket = bucket

            st.write("Configuração aplicada com sucesso!")

# Aba 2: Visualização de Dados
with tab2:
    if 'df' in st.session_state:
        df = st.session_state.df
        
        st.write("Selecione as colunas que deseja visualizar:")
        selected_columns = st.multiselect("Colunas", options=df.columns.tolist(), default=df.columns.tolist())

        if selected_columns:
            st.write(df[selected_columns])
        else:
            st.write("Nenhuma coluna selecionada.")
    else:
        st.write("Por favor, carregue um arquivo na aba 'Upload e Configuração' primeiro.")
